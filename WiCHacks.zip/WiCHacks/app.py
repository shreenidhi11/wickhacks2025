import os
from flask import Flask, request, jsonify
import psycopg2
from flask_cors import cross_origin
from sentence_transformers import SentenceTransformer, util
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
similarity_model = SentenceTransformer('all-MiniLM-L6-v2')


# Database connection
def get_db_connection():
    conn = psycopg2.connect(
        host="ep-cool-morning-a8sog6qf-pooler.eastus2.azure.neon.tech",  # Your Neon host
        database="LostAndFoundDB",  # Your Neon database name
        user="neondb_owner",  # Your Neon user
        password="npg_JU7DawuVmgr8",  # Your Neon password
        sslmode="require"  # Ensures connection over SSL
    )
    return conn

# Get or create a user based on email
def get_or_create_user(name, email, phone):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT user_id FROM users WHERE email = %s", (email,))
    user = cur.fetchone()
    if not user:
        cur.execute("INSERT INTO users (name, email, phone) VALUES (%s, %s, %s) RETURNING user_id", (name, email, phone))
        user_id = cur.fetchone()[0]
        conn.commit()
    else:
        user_id = user[0]
    cur.close()
    conn.close()
    return user_id


import smtplib
from email.mime.text import MIMEText

def send_email(to_email, subject, body):
    sender_email = "wichacks8@gmail.com"  # Replace with your email
    sender_password = "jpcteedtmikbrssh"  # app password
    # sender_password = "wichacks@888"  # Replace with your password or app password
    smtp_server = "smtp.gmail.com"  # Gmail SMTP server
    smtp_port = 587  # Gmail SMTP port (587 for TLS)

    try:
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = sender_email
        msg['To'] = to_email

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # Use TLS encryption
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, to_email, msg.as_string())
        print(f"Email sent successfully to {to_email}")
    except Exception as e:
        print(f"Error sending email: {e}")


# Add Lost Item API Endpoint (Modified to Check for Matching Found Items)
@app.route('/add_lost_item', methods=['POST'])
@cross_origin(origins="http://localhost:3000")
def add_lost_item():
    data = request.json
    user_id = get_or_create_user(data['name'], data['email'], data.get('phone', ''))
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO lost (user_id, item_name, category, color, item_location, description, image_url, date_lost, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'lost') RETURNING lost_id
        """,
        (user_id, data['item_name'], data['category'], data['color'], data['item_location'],
         data['description'], "https://" + data.get('image_url', None), data['date_lost'])
    )
    lost_id = cur.fetchone()[0]
    conn.commit()

    # Fetch info of all unclaimed found items
    cur.execute("""
    SELECT found_id, user_id, description 
    FROM found 
    WHERE status = 'unclaimed' 
    AND item_location = %s 
    AND category = %s
    """, (data['item_location'], data['category']))
    found_items = cur.fetchall()
    print("found items", found_items)

    # Prepare texts for similarity comparison
    reference_text = data['description']  # Lost item description
    comparison_texts = [item[2] for item in found_items]  # List of found item descriptions

    if comparison_texts:
        # Encode descriptions
        ref_embedding = similarity_model.encode(reference_text, convert_to_tensor=True)
        comp_embeddings = similarity_model.encode(comparison_texts, convert_to_tensor=True)
        
        # Compute cosine similarity
        similarity_scores = util.pytorch_cos_sim(ref_embedding, comp_embeddings)[0].tolist()
        print(similarity_scores)
        
        # Find the best match
        best_match_idx = similarity_scores.index(max(similarity_scores))
        best_match_score = similarity_scores[best_match_idx]
        print("best match score", best_match_score)

        if best_match_score > 0.6:  # Threshold to determine a match
            best_match_id, founder_id, _ = found_items[best_match_idx]
            # Insert match into match table with current timestamp
            cur.execute(
                """
                INSERT INTO match (lost_id, found_id, matched_at)
                VALUES (%s, %s, NOW())
                """, (lost_id, best_match_id)
            )
            conn.commit()

            # Insert into claim table
            cur.execute(
                """
                INSERT INTO claim (lost_id, found_id, claimer_id, status)
                VALUES (%s, %s, %s, 'Approved')
                """, (lost_id, best_match_id, user_id)
            )
            conn.commit()

            # Update status of the found item to 'claimed'
            cur.execute(
                """
                UPDATE found 
                SET status = 'claimed' 
                WHERE found_id = %s
                """, (best_match_id,)
            )
            conn.commit()

            # Update status of the lost item to 'claimed'
            cur.execute(
                """
                UPDATE lost 
                SET status = 'claimed' 
                WHERE lost_id = %s
                """, (lost_id,)
            )
            conn.commit()

            # Send email notification (implement send_email function)
            owner_email = data['email']
            subject = "Your Lost Item May Have Been Found!"
            body = f"We found a potential match for your lost item: {data['item_name']} \n\n Description: {data['description']} \n\n Please collect during the cage working hours."
            send_email(owner_email, subject, body)

    cur.close()
    conn.close()

    return jsonify({"message": "Lost item added", "lost_id": lost_id}), 201


# Add Found Item API Endpoint (No Changes)
@app.route('/add_found_item', methods=['POST'])
@cross_origin(origins="http://localhost:3000")
def add_found_item():
    data = request.json
    print(data)
    user_id = get_or_create_user(data['name'], data['email'], data.get('phone', ''))
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO found (user_id, item_name, category, color, item_location, description, image_url, date_found, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'unclaimed') RETURNING found_id
        """,
        (user_id, data['item_name'], data['category'], data['color'], data['item_location'],
         data['description'], "https://" + data.get('image_url', None), data['date_found'])
    )
    found_id = cur.fetchone()[0]
    conn.commit()

    cur.execute("""
    SELECT lost_id, user_id, item_name, description 
    FROM lost 
    WHERE status = 'lost' 
    AND item_location = %s 
    AND category = %s
    """, (data['item_location'], data['category']))
    lost_items = cur.fetchall()
    print("lost items", lost_items)

    # Prepare texts for similarity comparison
    reference_text = data['description']  # Lost item description
    comparison_texts = [item[3] for item in lost_items]  # List of found item descriptions

    if comparison_texts:
        # Encode descriptions
        ref_embedding = similarity_model.encode(reference_text, convert_to_tensor=True)
        comp_embeddings = similarity_model.encode(comparison_texts, convert_to_tensor=True)
        
        # Compute cosine similarity
        similarity_scores = util.pytorch_cos_sim(ref_embedding, comp_embeddings)[0].tolist()
        print(similarity_scores)

        # Find the best match
        best_match_idx = similarity_scores.index(max(similarity_scores))
        best_match_score = similarity_scores[best_match_idx]
        print("best match score", best_match_score)

        if best_match_score > 0.6:  # Threshold to determine a match
            best_match_id, claimer_id, item_name, item_description = lost_items[best_match_idx]
            # Insert match into match table with current timestamp
            cur.execute(
                """
                INSERT INTO match (lost_id, found_id, matched_at)
                VALUES (%s, %s, NOW())
                """, (best_match_id, found_id)
            )
            conn.commit()

            # Insert into claim table
            cur.execute(
                """
                INSERT INTO claim (lost_id, found_id, claimer_id, status)
                VALUES (%s, %s, %s, 'Approved')
                """, (best_match_id, found_id, claimer_id)
            )
            conn.commit()

            # Update status of the found item to 'claimed'
            cur.execute(
                """
                UPDATE found 
                SET status = 'claimed' 
                WHERE found_id = %s
                """, (found_id,)
            )
            conn.commit()

            # Update status of the lost item to 'claimed'
            cur.execute(
                """
                UPDATE lost 
                SET status = 'claimed' 
                WHERE lost_id = %s
                """, (best_match_id,)
            )
            conn.commit()

            # Send email notification (implement send_email function)
            cur.execute("SELECT email FROM users WHERE user_id = %s", (claimer_id,))
            claimer_email = cur.fetchone()[0]

            subject = "Your Lost Item May Have Been Found!"
            body = f"We found a potential match for your lost item: {item_name} \n\n Description: {item_description} \n\n Please collect during the cage working hours."
            send_email(claimer_email, subject, body)

    cur.close()
    conn.close()

    return jsonify({"message": "Found item added", "found_id": found_id}), 201


if __name__ == '__main__':
    app.run(port=3003, debug=True)
