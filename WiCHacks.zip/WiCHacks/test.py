import pytest
import json
from app import app  

@pytest.fixture
def client():
    """Creates a test client for the Flask app."""
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_add_lost_item(client):
    """Test the /add_lost_item API endpoint."""

    lost_item_data = {
        "name": "Rahul Jain",
        "email": "rahul@example.com",
        "phone": "0000567890",
        "item_name": "Jacket",
        "category": "Cloth",
        "color": "Blue",
        "item_location" : "GCCIS",
        "description": "it is a nike pro blue m size men jacket",
        "image_url": "http://example.com/image.jpg",
        "date_lost": "2025-02-28"
    }

    response = client.post("/add_lost_item", json=lost_item_data)
    assert response.status_code == 201  # Ensure item is successfully added
    response_json = response.get_json()
    assert response_json["message"] == "Lost item added"

def test_add_found_item(client):
    """Test the /add_found_item API endpoint."""

    found_item_data = {
        "name": "Samuel Nick",
        "email": "samuel@example.com",
        "phone": "9777700210",
        "item_name": "Jacket",
        "category": "Cloth",
        "color": "Blue",
        "item_location" : "GCCIS",
        "description": "nike pro blue men jacket m size",
        "image_url": "http://example.com/image.jpg",
        "date_found": "2025-03-01"
    }

    response = client.post("/add_found_item", json=found_item_data)
    assert response.status_code == 201  # Ensure item is successfully added
    response_json = response.get_json()
    assert response_json["message"] == "Found item added"

if __name__ == "__main__":
    pytest.main()
