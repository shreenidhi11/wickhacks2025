import React from 'react'
import '../components/Header.css'


function Header() {
    return (
        <div className='header'>
            <h2 className='title'>Rochester Institute of Technology</h2>
            <h3 className='subtitle'>Department of Lost and Found</h3>
        </div>
    )
}

export default Header