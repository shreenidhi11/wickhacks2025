import React, { useState } from "react";
import Header from "./Header";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../components/ReportFoundItem.css'

function ReportFoundItem() {
    const [formData, setFormData] = useState({
        personName: "",
        email: "",
        phoneNum: "",
        itemName: "",
        category:"",
        color: "",
        description: "",
        file: "",
        datefound: ""
      });
    
      const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        
        const response = await fetch("http://localhost:5000/api/report-found", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });
    
        const data = await response.json();
        console.log("Response from backend:", data);
      };


    return (
        <div className="container">
            <form onSubmit={handleSubmit}>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Name</label>
                        <input name="personName" type="text" class="form-control" id="inputEmail4" placeholder="Email" onChange={handleChange} required/>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPassword4">Email</label>
                        <input name="email" type="email" class="form-control" id="inputPassword4" placeholder="xyz@gmail.com" onChange={handleChange} required/>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPhonenumber4">Phone Number</label>
                        <input name="phoneNum" type="number" class="form-control" id="inputPhonenumber4" placeholder="1234" onChange={handleChange} />
                    </div>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress">Item Name</label>
                    <input name="itemName" type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" onChange={handleChange} required/>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputState">Category</label>
                    <select name="category" id="inputState" class="form-control" onChange={handleChange} required>
                        <option selected>Choose...</option>
                        <option>Electronics</option>
                        <option>Stationary</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputCity">Color</label>
                        <input name="color" type="text" class="form-control" id="inputCity" onChange={handleChange} required/>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="inputZip">Description</label>
                        <textarea  name="description" type="text" class="form-control" id="inputZip" onChange={handleChange} required />
                    </div>

                    <div class="form-group col-md-6">
                        <label for="inputZip">Image Upload</label>
                        <input name= "file" type="file" class="form-control" id="inputZip"  onChange={handleChange} required/>
                    </div>

                    <div class="form-group col-md-4">
                        <label for="inputZip">Date Found</label>
                        <input name="datefound" type="date" class="form-control" id="inputZip" onChange={handleChange}  required />
                    </div>
                </div>
                <br></br>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    );
}

export default ReportFoundItem;